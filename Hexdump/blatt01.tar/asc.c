#include <stdio.h>
int main (int argc, char *argv [], char *envp []) {
	 printf("%s\n", "Oct\tDec\tHex\tChar");
	 int counter = 0;
	 while(counter < 128) {
		 printf("%03o\t%-3d\t%02x\t%c\n", counter, counter, counter, counter);
		 counter++;
	 }
	return 0;
}