#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

int main (int argc, char *argv [], char *envp []){
    char *output = (char*) malloc(524 * sizeof(char));
    strncpy(output, "Hallo: ", 7);
    char *name = output + 7;
	int size = read(STDIN_FILENO, name, 256);
	strncpy(output + (size - 1) + 7, " -- ", 4);
	char *rot13 = output + (size - 1) + 11;
	strncpy(rot13, name, size - 1);
	
	int counter = 0;
	while((rot13[counter] >= 'A' && rot13[counter] <= 'Z') || (rot13[counter] >= 'a' && rot13[counter] <= 'z')) {
		if(rot13[counter] >= 'a' && rot13[counter] <= 'z') {
			rot13[counter] -= 32;
		}
		rot13[counter] += 13;
		if (rot13[counter] > 'Z') {
			rot13[counter] -= 26;
		}
		counter++;
	}
	*(rot13 + counter) = '\n';
	*(rot13 + counter + 1) = '\0';
	
	write(STDOUT_FILENO, output, (size - 1) + 12 + counter);
	free((void*) output);
	return 0;
}