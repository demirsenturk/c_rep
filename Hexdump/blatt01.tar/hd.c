#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

void hexdump (FILE *output, char *buffer, int length);

int main(int argc, char *argv[]) {
    FILE *output = stdout;
    for (int i = 1; i < argc; i++) {
        char *string = argv[i];
        int strlength = strlen(string);
        hexdump(output, string, strlength + 1);
        printf("\n");
    }

    fclose(output);
    return 0;
}
