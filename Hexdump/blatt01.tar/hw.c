#include <stdio.h>

int main (int argc, char *argv [], char *envp []) {
	char *hello = "Hello, world\n";
	printf("%s", hello);
	return 0;
}