#include <stdio.h>

void hexdump (FILE *output, char *buffer, int length)  {
    if (output != NULL) {
        int number_of_lines = (length + 15) / 16;
        for (int i = 0; i < number_of_lines; i++) {
            fprintf(output, "%06x : ", i * 16);
            if (i != number_of_lines - 1) {
                for (int j = 0; j < 16; j++) {
                    fprintf(output, "%02x ", buffer[i * 16 + j] & 0xff);
                }
                fprintf(output, "  ");
                for (int j = 0; j < 16; j++) {
                    if (buffer[i * 16 + j] < 0x20 || buffer[i * 16 + j] > 0x7e) {
                        fprintf(output, ".");
                    } else {
                        fprintf(output, "%c", buffer[i * 16 + j]);
                    }
                }
                fprintf(output, "\n");
            } else {
                int remaining_chars = 16 - (number_of_lines * 16 - length);
                for (int j = 0; j < remaining_chars; j++) {
                    fprintf(output, "%02x ", buffer[i * 16 + j] & 0xff);
                }
                for (int j = 0; j < 16 - remaining_chars; j++) {
                    fprintf(output, "   ");
                }
                fprintf(output, "  ");
                for (int j = 0; j < remaining_chars; j++) {
                    if (buffer[i * 16 + j] < 0x20 || buffer[i * 16 + j] > 0x7e) {
                        fprintf(output, ".");
                    } else {
                        fprintf(output, "%c", buffer[i * 16 + j]);
                    }
                }
                fprintf(output, "\n");
            }
        }
    }
}

