#include <stdlib.h>
#include <stdio.h>
#include <string.h>

struct list_elem {
    struct list_elem *next;
    char *data;
};

typedef struct list {
    struct list_elem *first;
    struct list_elem *last;
} list_t;

list_t *list_init() {
    list_t *new_list = malloc(sizeof(list_t)); // malloc
    new_list->first = NULL;
    new_list->last = NULL;
    return new_list;
}

struct list_elem *list_insert(list_t *list, char* data) {
    if (data == NULL || list == NULL) return NULL;
    if (list->first == NULL) {
        struct list_elem *new_elem = malloc(sizeof(struct list_elem)); // malloc
        new_elem->data = data;
        new_elem->next = NULL;
        list->first = new_elem;
        list->last = new_elem;
        return new_elem;
    }
    struct list_elem *new_elem = malloc(sizeof(struct list_elem)); // malloc
    new_elem->data = data;
    new_elem->next = list->first;
    list->first = new_elem;
    return new_elem;
}

struct list_elem *list_append(list_t *list, char *data) {
	if (data == NULL || list == NULL) return NULL;
    if (list->first == NULL) {
        struct list_elem *new_elem = malloc(sizeof(struct list_elem)); // malloc
        new_elem->data = data;
        new_elem->next = NULL;
        list->first = new_elem;
        list->last = new_elem;
        return new_elem;
    }
	struct list_elem *new_elem = malloc(sizeof(struct list_elem)); // malloc

	new_elem->data = data;
	new_elem->next = NULL;
	list->last->next = new_elem;
    list->last = new_elem;
	return new_elem;
}

int list_remove (list_t *list, struct list_elem *elem) {
    struct list_elem *prev_elem = list->first;
	//List leer
    if (prev_elem == NULL) {
        return -1;
    }
	struct list_elem *buffer_elem = prev_elem->next;
	//List mit 1 Element
	if (buffer_elem == NULL) {
		if (prev_elem == elem) {
            free(prev_elem);
            list->first = NULL;
            list->last = NULL;
			return 0;
		} else {
			return -1;
		}
	}
    
	//List mit n>1 Elementen
	if (prev_elem == elem) {
		list->first = buffer_elem;
		free(prev_elem);
		return 0;
	}
	while (buffer_elem != NULL) {
		if (buffer_elem == elem) {
			prev_elem->next = buffer_elem->next;
			//Letztes Element ist geloescht, list.last aktualisieren.
			if (prev_elem->next == NULL) {
				list->last = prev_elem;
			}
			free(buffer_elem);
			return 0;
		}
		prev_elem = buffer_elem;
		buffer_elem = prev_elem->next;
	}
	return -1;
}

void list_finit (list_t *list) {
	while (list->first != NULL) {
		list_remove(list, list->first);
	}
}

void list_print(list_t *list, char (*print_elem) (char *)) {
    if (list ==  NULL) return;
	struct list_elem *current_elem = list->first;
	int nummer = 1;
	while (current_elem != NULL && current_elem != list->last) {
		printf("%d:", nummer);
		print_elem(current_elem->data);
		printf("\n");
		nummer++;
		current_elem = current_elem->next;
	}
    if (list->last != NULL) {
        printf("%d:", nummer);
        print_elem(list->last->data);
        printf("\n");   
    }
}

void print_string(char *data){
    if (data == NULL) return;
    int i = 0;
    while (data[i] != '\0') {
        printf("%c", data[i]);
        i++;
    }
}

struct list_elem *list_find (list_t *list, char* data, int (*cmp_elem) (const char *, const char *)) {
    if (list == NULL || data == NULL) return NULL;
    struct list_elem *compared_elem = list->first;
    if (compared_elem == NULL) return NULL;
    while (1) {
        if (cmp_elem(compared_elem->data, data) == 0) {
            return compared_elem;
        }
        if (compared_elem->next != NULL) compared_elem = compared_elem->next;
        else return NULL;
    }

}

int cmp_elem (const char *first_array, const char *second_array) {
    return strncmp(first_array, second_array, 256);
}

