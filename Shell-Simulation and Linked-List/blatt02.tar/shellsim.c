#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main() {
	FILE *input_source = stdin;
	while (1) {
		char user_string[256];
		char *exit = "exit";
		fgets(user_string, 255, input_source);
		if (0 == strncmp(user_string, exit, 4)) break;
		system(user_string);
	}
	fclose(input_source);
}