﻿#include "list.h"
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[], char *envp[]) {
	list_t *li;
	li = list_init();
	char *string;
	for (int i = 1; i < argc; i++) {
        string = argv[i];
		if (*string != '-') {
			perror("Ungueltige Parameter!");
			return -1;
		}
		if (i + 1 >= argc) {
			perror("Ungueltige Parameter!");
			return -1;
		}
        switch (*(string + 1)) {
			case 'a':
			list_append(li, argv[++i]);
			break;
			case 'i':
			list_insert(li, argv[++i]);
			break;
			case 'r':
			list_remove(li, list_find(li, argv[++i], cmp_elem));
			break;
			default:
			perror("Ungueltige Parameter!");
			return -1;
		}
    }
	list_print(li, print_string);
	list_finit(li);
	return 0;
}